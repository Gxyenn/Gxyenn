const { Octokit } = require('@octokit/rest');

module.exports = async (req, res) => {
    if (req.method !== 'POST') {
        return res.status(405).json({ message: 'Method Not Allowed' });
    }

    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const { repo: repoFullName } = req.body;
        if (!repoFullName) {
            return res.status(400).json({ message: 'Nama repo dibutuhkan.' });
        }

        const [owner, repo] = repoFullName.split('/');
        const octokit = new Octokit({ auth: token });

        let branch = 'main';
        try {
            const repoData = await octokit.rest.repos.get({ owner, repo });
            branch = repoData.data.default_branch;
        } catch (e) {
            console.warn(`Could not get default branch for ${repoFullName}, falling back to 'main'.`);
        }

        await octokit.rest.repos.createOrUpdateFileContents({
            owner,
            repo,
            path: 'Cache',
            message: 'Initial commit by Uploader Pro',
            content: Buffer.from('This file was created to initialize the repository.').toString('base64'),
            branch: branch,
        });

        res.status(200).json({ message: 'Cache file created successfully.' });

    } catch (error) {
        console.error('Create cache error:', error);
        res.status(500).json({ message: error.message || 'Gagal membuat file cache.' });
    }
};
