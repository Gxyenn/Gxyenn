const axios = require('axios');

module.exports = async (req, res) => {
    const { code } = req.query;
    if (!code) {
        return res.status(400).send('Error: Authorization code is missing.');
    }

    try {
        const response = await axios.post('https://github.com/login/oauth/access_token', {
            client_id: process.env.GITHUB_CLIENT_ID,
            client_secret: process.env.GITHUB_CLIENT_SECRET,
            code: code,
        }, {
            headers: { 'Accept': 'application/json' }
        });

        const { access_token } = response.data;
        if (!access_token) {
            return res.status(400).send('Error: Could not retrieve access token.');
        }
        
        res.redirect(`/ldu/?token=${access_token}`);

    } catch (error) {
        console.error('Error in callback:', error.response ? error.response.data : error.message);
        res.status(500).send('Internal Server Error');
    }
};
