const { Octokit } = require('@octokit/rest');
const formidable = require('formidable');
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

// Vercel-specific config to disable default body parsing
module.exports.config = {
    api: { bodyParser: false },
};

const parseForm = (req) => new Promise((resolve, reject) => {
    const form = formidable({ multiples: true, maxFileSize: 25 * 1024 * 1024 }); // Limit 25 MB
    form.parse(req, (err, fields, files) => {
        if (err) return reject(err);
        const fileArray = Array.isArray(files.files) ? files.files : [files.files].filter(Boolean);
        resolve({ fields, files: fileArray });
    });
});

module.exports = async (req, res) => {
    if (req.method !== 'POST') {
        return res.status(405).json({ message: 'Method Not Allowed' });
    }

    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'Unauthorized: Token tidak ditemukan.' });
    }

    try {
        const { fields, files } = await parseForm(req);
        const repoFullName = fields.repo;
        const folderPath = fields.folderPath || '';
        const filesToExtract = fields.extract ? JSON.parse(fields.extract) : [];

        if (!files || files.length === 0 || !repoFullName || !/.*\/.*/.test(repoFullName)) {
            return res.status(400).json({ message: 'Input tidak valid.' });
        }
        
        const [owner, repo] = repoFullName.split('/');
        const octokit = new Octokit({ auth: token });
        
        let branch = 'main';
        try {
            const repoData = await octokit.rest.repos.get({ owner, repo });
            branch = repoData.data.default_branch;
        } catch (e) {
             if (e.status === 404) return res.status(404).json({ message: 'Repositori tidak ditemukan.' });
             console.warn(`Could not get default branch, falling back to 'main'.`);
        }

        
        // Get reference (commit SHA) of the branch
        let parentCommitSha;
        try {
            const { data: refData } = await octokit.rest.git.getRef({ owner, repo, ref: `heads/${branch}` });
            parentCommitSha = refData.object.sha;
        } catch (e) {
            // If branch does not exist, create it from default branch commit
            if (e.status === 404) {
                const { data: repoData } = await octokit.rest.repos.get({ owner, repo });
                const defaultBranch = repoData.default_branch || 'main';
                const { data: defaultRef } = await octokit.rest.git.getRef({ owner, repo, ref: `heads/${defaultBranch}` });
                parentCommitSha = defaultRef.object.sha;
                // create new branch ref
                await octokit.rest.git.createRef({
                    owner,
                    repo,
                    ref: `refs/heads/${branch}`,
                    sha: parentCommitSha,
                });
            } else {
                throw e;
            }
        }

        // Get the commit object to retrieve its tree SHA (required for createTree's base_tree)
        const { data: parentCommit } = await octokit.rest.git.getCommit({ owner, repo, commit_sha: parentCommitSha });
        const baseTreeSha = parentCommit.tree.sha;

        const fileBlobs = [];
        for (const file of files) {
            if (filesToExtract.includes(file.originalFilename)) {
                // Ekstrak file zip
                const zip = new AdmZip(file.filepath);
                zip.getEntries().forEach(entry => {
                    if (!entry.isDirectory) {
                        const finalPath = folderPath ? path.join(folderPath, entry.entryName).replace(/\\/g, '/') : entry.entryName.replace(/\\/g, '/');
                        fileBlobs.push({ path: finalPath, content: entry.getData() });
                    }
                });
            } else {
                // Upload file biasa
                const finalPath = folderPath ? path.join(folderPath, file.originalFilename).replace(/\\/g, '/') : file.originalFilename;
                fileBlobs.push({ path: finalPath, content: fs.readFileSync(file.filepath) });
            }
        }
        
        if(fileBlobs.length === 0) {
            return res.status(400).json({ message: 'Tidak ada file untuk diupload.' });
        }

        const tree = await Promise.all(
            fileBlobs.map(async (file) => {
                const { data: blobData } = await octokit.rest.git.createBlob({
                    owner, repo,
                    content: Buffer.from(file.content).toString('base64'),
                    encoding: 'base64',
                });
                return {
                    path: file.path,
                    sha: blobData.sha,
                    mode: '100644',
                    type: 'blob',
                };
            })
        );
        
        const { data: treeData } = await octokit.rest.git.createTree({ owner, repo, tree, base_tree: baseTreeSha });
        const { data: commitData } = await octokit.rest.git.createCommit({
            owner, repo,
            message: `Upload ${fileBlobs.length} item(s) via Uploader Pro`,
            tree: treeData.sha,
            parents: [parentCommitSha],
        });
        await octokit.rest.git.updateRef({ owner, repo, ref: `heads/${branch}`, sha: commitData.sha });
        
        res.status(200).json({ message: `Sukses! ${fileBlobs.length} item berhasil diupload.` });

    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ message: error.message || 'Terjadi kesalahan di server.' });
    }
};
